# telenor
 Knowledge Systems Specialist
